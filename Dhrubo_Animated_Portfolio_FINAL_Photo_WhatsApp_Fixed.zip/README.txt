DHRUBO — ANIMATED PERSONAL PORTFOLIO
=====================================

Updated version:
- Professional portrait is embedded directly inside index.html, so it remains attached when the site is uploaded.
- Correct phone/WhatsApp number: 01734140846
- Direct WhatsApp button: https://wa.me/8801734140846
- Responsive mobile/desktop layout
- Smooth scroll, reveal animations, typing headline and animated skill bars

Publish:
Upload index.html to your static host. No separate image upload is required because the profile photo is embedded in the HTML.
